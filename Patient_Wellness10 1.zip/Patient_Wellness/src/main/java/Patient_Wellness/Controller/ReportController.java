package Patient_Wellness.Controller;
 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import Patient_Wellness.Entity.Report;
import Patient_Wellness.Service.ReportService;
 
 
@RestController
@RequestMapping("/api/reports")
@Validated
public class ReportController {
 
@Autowired
private ReportService reportService;
 
@PostMapping("/generate/{patientId}")
public ResponseEntity<Report> generateReport(@Valid @RequestBody Report report ,@PathVariable Long patientId) {
	return ResponseEntity.ok(reportService.generateReport(report ,patientId));
 
}
 
 
@GetMapping("/{patientId}")
public ResponseEntity<List<Report>> getReports(@PathVariable Long patientId) {
	return ResponseEntity.ok(reportService.getReportsByPatient(patientId));
 
}
 
}