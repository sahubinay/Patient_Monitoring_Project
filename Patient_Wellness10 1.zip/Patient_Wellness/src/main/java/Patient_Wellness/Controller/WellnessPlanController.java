package Patient_Wellness.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import Patient_Wellness.Entity.WellnessPlan;
import Patient_Wellness.Service.WellnessPlanService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/plans")
@Validated
public class WellnessPlanController {

    @Autowired
    private WellnessPlanService wellnessService;

    @PostMapping("/create/{patientId}")
    public ResponseEntity<WellnessPlan> createPlan(
            @Valid @RequestBody WellnessPlan plan,
            @PathVariable Long patientId) {
        
        WellnessPlan created = wellnessService.createPlan(plan, patientId);
        return ResponseEntity.ok(created);
    }

    @GetMapping
    public ResponseEntity<List<WellnessPlan>> getAllPlans() {
        return ResponseEntity.ok(wellnessService.getAllPlans());
    }
}
