package Patient_Wellness.Controller;

import Patient_Wellness.Entity.User;
import Patient_Wellness.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize; // New Import
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    // ✅ Endpoint to check if JWT token is valid and get current username
    @GetMapping("/me")
    public ResponseEntity<String> getCurrentUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return ResponseEntity.ok("You are logged in as: " + username);
    }

    // ✅ ADMIN only access: This endpoint requires the authenticated user to have the 'ADMIN' role.
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.findAll());
    }
}