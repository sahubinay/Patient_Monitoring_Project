// PatientProfileController.java
package Patient_Wellness.Controller;
 
import Patient_Wellness.Entity.PatientProfile;
import Patient_Wellness.Service.PatientProfileService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
 
@RestController
@RequestMapping("/api/patients")
@Validated
public class PatientProfileController {
 
    @Autowired
    private PatientProfileService patientService;
 
    @PostMapping("/register")
    public ResponseEntity<PatientProfile> registerPatient(@Valid @RequestBody PatientProfile patient) {
        return ResponseEntity.ok(patientService.registerPatient(patient));
    }
 
    @GetMapping("/{id}")
    public ResponseEntity<PatientProfile> getPatient(@PathVariable Long id) {
        return patientService.getPatientById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("")
    public ResponseEntity<List<PatientProfile>> getAllPatients() {
        return ResponseEntity.ok(patientService.getAllPatients());
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<PatientProfile> updatePatient(@PathVariable Long id, @Valid @RequestBody PatientProfile updatedProfile) {
        Optional<PatientProfile> optionalPatient = patientService.getPatientById(id);
        if (optionalPatient.isPresent()) {
            PatientProfile patient = optionalPatient.get();
            patient.setName(updatedProfile.getName());
            patient.setAge(updatedProfile.getAge());
            patient.setContactDetails(updatedProfile.getContactDetails());
            patient.setMedicalHistory(updatedProfile.getMedicalHistory());
            return ResponseEntity.ok(patientService.registerPatient(patient));
        } else {
            return ResponseEntity.notFound().build();
        }
    }
 
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePatient(@PathVariable Long id) {
        if (patientService.deletePatientById(id)) {
            return ResponseEntity.ok("Patient deleted successfully.");
        } else {
            return ResponseEntity.status(404).body("Patient not found.");
        }
    }
}
 