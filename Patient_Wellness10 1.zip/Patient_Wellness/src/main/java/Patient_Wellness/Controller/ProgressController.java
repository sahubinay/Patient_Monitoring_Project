package Patient_Wellness.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import Patient_Wellness.Entity.Progress;
import Patient_Wellness.Service.ProgressService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/progress")
@Validated
public class ProgressController {

    @Autowired
    private ProgressService progressService;

    @PostMapping("/track")
    public ResponseEntity<Progress> trackProgress(@Valid @RequestBody Progress progress) {
        return ResponseEntity.ok(progressService.trackProgress(progress));
    }

    @GetMapping("/{patientId}")
    public ResponseEntity<List<Progress>> getProgress(@PathVariable Long patientId) {
        List<Progress> progressList = progressService.getProgressByPatient(patientId);
        if (progressList.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(progressList);
    }
}

