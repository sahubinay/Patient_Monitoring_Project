package Patient_Wellness.Controller;

import Patient_Wellness.Entity.User;
import Patient_Wellness.Service.UserService;
import Patient_Wellness.Util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

// Inner class to handle login request body
class LoginRequest {
    private String username;
    private String password;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        if (userService.validateCredentials(loginRequest.getUsername(), loginRequest.getPassword())) {
            String token = jwtUtil.generateToken(loginRequest.getUsername());

            Optional<User> optionalUser = userService.findByUsername(loginRequest.getUsername());
            if (optionalUser.isEmpty()) {
                // This case should ideally not happen if validateCredentials passed, but good for robustness
                return ResponseEntity.status(404).body("User not found");
            }

            User user = optionalUser.get();

            Map<String, String> response = new HashMap<>();
            response.put("token", token);
            response.put("username", user.getUsername());
            response.put("role", user.getRole()); // Include the user's role

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body("Invalid username or password");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        if (user.getUsername() == null || user.getUsername().isEmpty() ||
            user.getPassword() == null || user.getPassword().isEmpty()) {
            return ResponseEntity.badRequest().body("Username and password cannot be empty.");
        }

        if (userService.findByUsername(user.getUsername()).isPresent()) {
            return ResponseEntity.status(409).body("Username already exists.");
        }

        User registeredUser = userService.registerNewUser(user);
        return ResponseEntity.ok("User '" + registeredUser.getUsername() + "' registered successfully.");
    }
}