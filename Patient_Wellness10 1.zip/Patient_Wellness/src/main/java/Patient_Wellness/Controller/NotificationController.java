package Patient_Wellness.Controller;
 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import Patient_Wellness.Entity.Notification;
import Patient_Wellness.Service.NotificationService;
 
 
@RestController
@RequestMapping("/api/notifications")
@Validated
public class NotificationController {
 
 
@Autowired
private NotificationService notificationService;
 
 
@PostMapping("/send/{patientId}")
public ResponseEntity<Notification> sendNotification(@Valid @RequestBody Notification notification ,@PathVariable Long patientId) {
 
	return ResponseEntity.ok(notificationService.sendNotification(notification , patientId));
 
}
 
 
@GetMapping("/{patientId}")
public ResponseEntity<List<Notification>> getNotifications(@PathVariable Long patientId) {
 
return ResponseEntity.ok(notificationService.getNotificationsByPatient(patientId));
 
}
 
}