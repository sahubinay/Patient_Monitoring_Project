package Patient_Wellness.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "progress")
@Getter
@Setter
public class Progress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long progressId;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false)
    @JsonBackReference // Prevent infinite recursion
    private PatientProfile patient;

    @ManyToOne
    @JoinColumn(name = "plan_id", nullable = false)
    private WellnessPlan plan;

    @NotBlank(message = "Completed activities cannot be blank")
    private String completedActivities;
}
