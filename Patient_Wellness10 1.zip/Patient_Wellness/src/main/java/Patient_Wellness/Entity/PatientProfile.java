package Patient_Wellness.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;



@Entity
@Table(name = "patient_profiles")
@Getter
@Setter
public class PatientProfile {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long patientId;



@NotBlank(message = "Name cannot be blank")
private String name;



@Min(value = 0, message = "Age must be non-negative")
private int age;



@NotBlank(message = "Contact details cannot be blank")
private String contactDetails;



@NotBlank(message = "Medical history cannot be blank")
private String medicalHistory;

}
