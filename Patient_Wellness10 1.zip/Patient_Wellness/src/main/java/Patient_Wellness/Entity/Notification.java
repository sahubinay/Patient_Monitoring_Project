package Patient_Wellness.Entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;



@Entity
@Table(name = "notifications")
@Getter
@Setter
public class Notification {



@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long notificationId;



@ManyToOne
@JoinColumn(name = "patient_id")
private PatientProfile patient;



@NotBlank(message = "Message cannot be blank")
private String message;

private LocalDateTime timestamp;

}

