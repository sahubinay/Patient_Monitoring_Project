package Patient_Wellness.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "wellness_plans")
@Getter
@Setter
public class WellnessPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long planId;

    @NotBlank(message = "Plan name cannot be blank")
    private String planName;

    @NotBlank(message = "Activities cannot be blank")
    private String activities;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "patient_id", nullable = false)
    @JsonBackReference // Prevents infinite recursion if PatientProfile links back
    private PatientProfile assignedTo;
}
