package Patient_Wellness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity; // New Import

@SpringBootApplication
@EnableMethodSecurity // Enable role-based access control here
public class PatientWellnessApplication {

    public static void main(String[] args) {
        SpringApplication.run(PatientWellnessApplication.class, args);
    }
}