package Patient_Wellness.Service;
 
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Patient_Wellness.Entity.Notification;
import Patient_Wellness.Entity.PatientProfile;
import Patient_Wellness.Repository.NotificationRepository;
import Patient_Wellness.Repository.PatientProfileRepository;
 
 
 
@Service
public class NotificationService {
 
@Autowired
private PatientProfileRepository patientRepo;
 
@Autowired
private NotificationRepository notificationRepo;
 
 
 
public Notification sendNotification(Notification notification,Long patientId) {
PatientProfile patient = patientRepo.findById(patientId).orElse(null);
notification.setTimestamp(java.time.LocalDateTime.now());
notification.setPatient(patient);
return notificationRepo.save(notification);
 
}
 
 
 
public List<Notification> getNotificationsByPatient(Long patientId) {
 
	return notificationRepo.findAll().stream()
 
.filter(n -> n.getNotificationId().equals(patientId))
 
.collect(Collectors.toList());
 
}
 
}
 