package Patient_Wellness.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Patient_Wellness.Entity.PatientProfile;
import Patient_Wellness.Entity.Progress;
import Patient_Wellness.Entity.WellnessPlan;
import Patient_Wellness.Repository.PatientProfileRepository;
import Patient_Wellness.Repository.ProgressRepository;
import Patient_Wellness.Repository.WellnessPlanRepository;

@Service
public class ProgressService {

    @Autowired
    private ProgressRepository progressRepo;

    @Autowired
    private WellnessPlanRepository planRepo;

    @Autowired
    private PatientProfileRepository patientRepo;

    public Progress trackProgress(Progress progress) {
        // Fetch full Patient entity
        Long patientId = progress.getPatient().getPatientId();
        PatientProfile patient = patientRepo.findById(patientId)
            .orElseThrow(() -> new IllegalArgumentException("Invalid patient ID: " + patientId));
        
        // Fetch full Plan entity
        Long planId = progress.getPlan().getPlanId();
        WellnessPlan plan = planRepo.findById(planId)
            .orElseThrow(() -> new IllegalArgumentException("Invalid plan ID: " + planId));

        // Set the fully loaded entities
        progress.setPatient(patient);
        progress.setPlan(plan);

        return progressRepo.save(progress);
    }

    public List<Progress> getProgressByPatient(Long patientId) {
        return progressRepo.findByPatient_PatientId(patientId);
    }
}