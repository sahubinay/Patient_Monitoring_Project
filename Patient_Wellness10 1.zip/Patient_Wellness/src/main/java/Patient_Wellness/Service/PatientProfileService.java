// PatientProfileService.java
package Patient_Wellness.Service;
 
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import Patient_Wellness.Entity.PatientProfile;
import Patient_Wellness.Repository.PatientProfileRepository;
 
@Service
public class PatientProfileService {
 
    @Autowired
    private PatientProfileRepository patientRepo;
 
    public PatientProfile registerPatient(PatientProfile patient) {
        return patientRepo.save(patient);
    }
 
    public Optional<PatientProfile> getPatientById(Long id) {
        return patientRepo.findById(id);
    }
  
    public List<PatientProfile> getAllPatients() {
        return patientRepo.findAll();
    }
    
    public boolean deletePatientById(Long id) {
        if (patientRepo.existsById(id)) {
            patientRepo.deleteById(id);
            return true;
        }
        return false;
    }
}