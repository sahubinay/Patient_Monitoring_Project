package Patient_Wellness.Service;
 
import java.time.LocalDate;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
 
import Patient_Wellness.Entity.PatientProfile;

import Patient_Wellness.Entity.Report;

import Patient_Wellness.Repository.PatientProfileRepository;

import Patient_Wellness.Repository.ReportRepository;
 
 
@Service

public class ReportService {

@Autowired

private ReportRepository reportRepo;
 
@Autowired

private PatientProfileRepository patientProfileRepo;
 
public Report generateReport(Report report ,Long patientId) 

{

	 PatientProfile patient = patientProfileRepo.findById(patientId).orElse(null);

	 report.setPatient(patient);

	 report.setDate(LocalDate.now());

return reportRepo.save(report);
 
}
 
 
public List<Report> getReportsByPatient(Long patientId)

{

return reportRepo.findAll().stream()
 
.filter(r -> r.getReportId().equals(patientId))
 
.collect(Collectors.toList());
 
}
 
}
 