package Patient_Wellness.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Patient_Wellness.Entity.WellnessPlan;
import Patient_Wellness.Entity.PatientProfile;
import Patient_Wellness.Repository.WellnessPlanRepository;
import Patient_Wellness.Repository.PatientProfileRepository;

@Service
public class WellnessPlanService {

    @Autowired
    private WellnessPlanRepository wellnessRepo;

    @Autowired
    private PatientProfileRepository patientRepo;

    public WellnessPlan createPlan(WellnessPlan plan, Long patientId) {
        PatientProfile patient = patientRepo.findById(patientId)
                .orElseThrow(() -> new IllegalArgumentException("Patient not found with ID: " + patientId));
        
        // Override any incoming patient in request
        plan.setAssignedTo(patient);
        return wellnessRepo.save(plan);
    }

    public List<WellnessPlan> getAllPlans() {
        return wellnessRepo.findAll();
    }
}

