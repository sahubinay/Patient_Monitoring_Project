package Patient_Wellness.Service;

import Patient_Wellness.Entity.User;
import Patient_Wellness.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Optional<User> findByUsername(String username) {
        return repo.findByUsername(username);
    }

    public User registerNewUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        // Set a default role if none is provided during registration
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("ROLE_USER"); // Default role for new users
        }
        return repo.save(user);
    }

    public boolean validateCredentials(String username, String rawPassword) {
        Optional<User> userOptional = repo.findByUsername(username);
        return userOptional.map(user -> passwordEncoder.matches(rawPassword, user.getPassword()))
                           .orElse(false);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = repo.findByUsername(username)
                        .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        // Spring Security expects roles prefixed with "ROLE_"
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .roles(user.getRole().replace("ROLE_", "")) // Ensure correct role format for Spring Security
                .build();
    }

    // New method to fetch all users (for admin access)
    public List<User> findAll() {
        return repo.findAll();
    }
}