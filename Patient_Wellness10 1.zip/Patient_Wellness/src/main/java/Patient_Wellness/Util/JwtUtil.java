package Patient_Wellness.Util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {
    // IMPORTANT: This secret string must be long enough for HS512 (at least 64 bytes/512 bits).
    // Using a 128-character string here to ensure sufficient length.
    // For production, retrieve this from environment variables or a secure configuration server,
    // and consider generating a random key using Keys.secretKeyFor(SignatureAlgorithm.HS512).
    private final String SECRET_STRING = "ThisIsAReallyLongAndSecureSecretKeyForJWTAuthenticationAndItsNowEvenLongerToEnsure512BitsAreMetProperlyForHS512AlgorithmExampleSecretKey"; // NOW 128 characters long
    private final long EXPIRATION_TIME = 1000 * 60 * 60 * 10; // 10 hours

    private final Key key;

    public JwtUtil() {
        this.key = Keys.hmacShaKeyFor(SECRET_STRING.getBytes());
    }

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            System.err.println("JWT Validation Error: " + e.getMessage());
            return false;
        }
    }
}